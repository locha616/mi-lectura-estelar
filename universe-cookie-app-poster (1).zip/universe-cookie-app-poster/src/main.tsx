import React from 'react'
import { createRoot } from 'react-dom/client'
import PlanLecturaCosmicoApp from './PlanLecturaCosmicoApp'
import './styles.css'

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <PlanLecturaCosmicoApp />
  </React.StrictMode>
)