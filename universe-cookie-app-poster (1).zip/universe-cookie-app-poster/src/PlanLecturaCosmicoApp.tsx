import React, { useEffect, useState } from 'react';

type Progress = Record<string, [boolean, boolean]>;

const WEEKS = [
  { id: 1, range: '21 - 27 oct', pages: ['8–19', '20–31'] },
  { id: 2, range: '28 oct - 3 nov', pages: ['32–43', '44–55'] },
  { id: 3, range: '4 - 10 nov', pages: ['56–67', '68–79'] },
  { id: 4, range: '11 - 17 nov', pages: ['80–91', '92–103'] },
  { id: 5, range: '18 - 24 nov', pages: ['104–115', '116–127'] },
  { id: 6, range: '25 - 30 nov', pages: ['128–139', '140 (final)'] },
];

const STORAGE_KEY = 'plan_cosmico_progress_poster_v1';

function CookieIcon({ className = 'w-8 h-8' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="30" fill="#D69E58" stroke="#000" strokeWidth="1.5"/>
      <g fill="#2D1F10">
        <circle cx="24" cy="22" r="3" />
        <circle cx="38" cy="28" r="2.8" />
        <circle cx="30" cy="38" r="2.6" />
        <circle cx="44" cy="36" r="2.6" />
      </g>
    </svg>
  );
}

function StarIcon({ lit = false, className = 'w-6 h-6' }: { lit?: boolean, className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2l2.6 6.4L21 10l-5 3.6L17.2 21 12 17.4 6.8 21 8 13.6 3 10l6.4-1.6L12 2z" fill={lit ? '#FFD166' : '#F0E9FF'} stroke="#000" strokeWidth="0.8"/>
    </svg>
  );
}

export default function PlanLecturaCosmicoApp(): JSX.Element {
  const [progress, setProgress] = useState<Progress>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  const playBling = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(880, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.25);
      g.gain.setValueAtTime(0, ctx.currentTime);
      g.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6);
      o.connect(g);
      g.connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + 0.7);
    } catch (e) {
      console.warn('Audio not available', e);
    }
  };

  const toggle = (weekIdx: number, sessionIdx: number) => {
    setProgress(prev => {
      const copy: Progress = { ...prev };
      const key = `w${weekIdx}`;
      const arr: [boolean, boolean] = copy[key] ? [copy[key][0], copy[key][1]] : [false, false];
      arr[sessionIdx] = !arr[sessionIdx];
      copy[key] = arr;
      return copy;
    });
    playBling();
  };

  const resetAll = () => {
    if (!confirm('¿Borrar todo el progreso y reiniciar?')) return;
    setProgress({});
  };

  const downloadPoster = () => {
    const posterHtml = document.getElementById('poster-template')?.innerHTML || '';
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write('<html><head><title>Mi Lectura Estelar - Poster</title>');
    w.document.write('<meta name="viewport" content="width=device-width, initial-scale=1.0">');
    w.document.write('<style>body{font-family:Inter,Arial,sans-serif;margin:0;padding:0} .poster{width:210mm;height:297mm;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:20mm;box-sizing:border-box;background:white} h1{font-size:36px;margin:0 0 12px} .subtitle{color:#6b21a8;margin-bottom:8px} .weeks{margin-top:12px} .week{margin-bottom:8px;display:flex;gap:8px;align-items:center} .pages{font-size:16px}</style>');
    w.document.write('</head><body>');
    w.document.write('<div class="poster">');
    w.document.write(posterHtml);
    w.document.write('</div>');
    w.document.write('</body></html>');
    w.document.close();
    w.focus();
    setTimeout(()=>{ w.print(); }, 500);
  };

  return (
    <div className="min-h-screen p-6 flex items-center justify-center">
      <div className="max-w-3xl w-full rounded-2xl shadow-2xl border border-gray-700 bg-white/70 backdrop-blur-sm overflow-hidden">
        <div className="relative p-6 flex items-center justify-between border-b border-gray-200 bg-white/90">
          <div className="flex items-center gap-4">
            <div className="flex -space-x-3">
              <div className="transform rotate-6"><CookieIcon className="w-14 h-14" /></div>
              <div className="-ml-3"><StarIcon lit={true} className="w-10 h-10" /></div>
              <div className="-ml-3 transform -rotate-6"><CookieIcon className="w-14 h-14" /></div>
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 leading-tight">Mi Lectura Estelar</h1>
              <p className="mt-1 text-sm text-indigo-700">“Cada página te acerca a las estrellas 🌠”</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Mi lectura estelar ✨</p>
            <button onClick={resetAll} className="mt-2 px-3 py-1 bg-red-50 text-red-700 rounded-full text-sm border border-red-100 hover:bg-red-100">
              Reiniciar
            </button>
          </div>
        </div>

        <div className="p-6">
          <p className="text-sm text-gray-600 mb-4">Objetivo: terminar el 30 de noviembre — 2 sesiones por semana (12 sesiones).</p>

          <div className="grid grid-cols-1 gap-4">
            {WEEKS.map((w) => {
              const key = `w${w.id}`;
              const arr = progress[key] || [false, false];
              const weekLit = arr[0] && arr[1];
              return (
                <div key={w.id} className="p-4 rounded-xl border border-gray-200 bg-white">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <div className="p-2 rounded-full bg-white shadow-sm">
                          <StarIcon lit={weekLit} />
                        </div>
                        <div>
                          <div className="text-sm font-semibold">Semana {w.id}</div>
                          <div className="text-xs text-gray-500">{w.range}</div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {w.pages.map((p, si) => (
                        <div key={si} className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg border border-gray-100">
                          <input
                            id={`c-${w.id}-${si}`}
                            type="checkbox"
                            checked={arr[si] || false}
                            onChange={() => toggle(w.id, si)}
                            className="w-5 h-5 rounded-md text-indigo-600 border-gray-300"
                          />
                          <div className="flex items-center gap-2">
                            <div className="text-sm font-medium">{p}</div>
                            <div className="ml-2"><CookieIcon className="w-6 h-6" /></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button onClick={() => window.print()} className="px-4 py-2 bg-indigo-600 text-white rounded-lg shadow hover:opacity-95">Imprimir / Guardar PDF</button>
            <button onClick={downloadPoster} className="px-4 py-2 bg-pink-600 text-white rounded-lg border border-pink-500 hover:bg-pink-700">Descargar mi póster estelar</button>
            <button onClick={() => {
              const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(progress));
              const dlAnchor = document.createElement('a');
              dlAnchor.setAttribute('href', dataStr);
              dlAnchor.setAttribute('download', 'plan_cosmico_progress.json');
              dlAnchor.click();
            }} className="px-4 py-2 bg-yellow-100 text-yellow-800 rounded-lg border border-yellow-200 hover:bg-yellow-200">Exportar progreso</button>

            <button onClick={() => {
              const share = encodeURIComponent(JSON.stringify(progress));
              navigator.clipboard?.writeText(window.location.origin + window.location.pathname + '?state=' + share);
              alert('Enlace de progreso copiado al portapapeles (puede incluir estado).');
            }} className="px-4 py-2 bg-green-50 text-green-700 rounded-lg border border-green-100 hover:bg-green-100">Copiar enlace con progreso</button>
          </div>

          <div className="mt-6 text-xs text-gray-400">Tip: marca las casillas para que las estrellitas se iluminen. El progreso se guarda en tu navegador.</div>
        </div>
      </div>

      {/* hidden poster template (used by downloadPoster) */}
      <div id="poster-template" style={{display:'none'}}>
        <div style={{textAlign:'center'}}>
          <h1>Mi Lectura Estelar</h1>
          <div className="subtitle">The Universe Explained with a Cookie</div>
          <div style={{marginTop:12}}>
            <img src="/public/favicon.svg" alt="cookie" style={{width:80,height:80}} />
          </div>
          <div className="weeks" style={{marginTop:20}}>
            {WEEKS.map(w => (
              `<div class="week"><strong>Semana ${w.id}:</strong> ${w.range} — Páginas: ${w.pages.join(' y ')}</div>`
            )).join('')}
          </div>
          <div style={{marginTop:24,fontSize:14}}>“Cada página te acerca a las estrellas 🌠”</div>
          <div style={{marginTop:18}}>Mi lectura estelar ✨</div>
        </div>
      </div>
    </div>
  );
}