# universe-cookie-app-poster

Proyecto Vite + React + TypeScript — app interactiva del plan de lectura cósmico + generación de póster imprimible.

## Ejecutar localmente

1. Instalar dependencias:
```bash
npm install
```

2. Ejecutar en modo desarrollo:
```bash
npm run dev
```

3. Abrir `http://localhost:5173` en tu navegador.

## Build
```bash
npm run build
npm run preview
```

## Notas
- El progreso se guarda en `localStorage` del navegador.
- El botón "Descargar mi póster estelar" abre una ventana preparada para imprimir en A4; usa el diálogo de impresión para guardar como PDF.
- Para desplegar en Netlify, configura **Build command**: `npm run build` y **Publish directory**: `dist`.